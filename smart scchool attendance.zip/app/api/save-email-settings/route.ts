import { type NextRequest, NextResponse } from "next/server"

export const emailSettings = {
  apiKey: "",
  fromDomain: "smartattenadacetracker.app",
}

export async function POST(request: NextRequest) {
  try {
    const { apiKey, fromDomain } = await request.json()

    if (!apiKey || !fromDomain) {
      return NextResponse.json({
        success: false,
        message: "API key and domain are required",
      })
    }

    // Validate API key format
    if (!apiKey.startsWith("re_")) {
      return NextResponse.json({
        success: false,
        message: "Invalid Resend API key format. Key should start with 're_'",
      })
    }

    emailSettings.apiKey = apiKey
    emailSettings.fromDomain = fromDomain

    return NextResponse.json({
      success: true,
      message: "Email settings saved successfully",
    })
  } catch (error) {
    console.error("Save email settings error:", error)
    return NextResponse.json({
      success: false,
      message: "Failed to save email settings",
    })
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    settings: {
      fromDomain: emailSettings.fromDomain,
      hasApiKey: !!emailSettings.apiKey,
    },
  })
}
