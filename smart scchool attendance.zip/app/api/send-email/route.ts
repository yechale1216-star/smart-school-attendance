import { type NextRequest, NextResponse } from "next/server"
import { Resend } from "resend"

const getValidApiKey = () => {
  const envKey = process.env.RESEND_API_KEY
  const providedKey = "re_EDGmqgDT_EQSWggMdcerQQ4Dt76vbskvH"

  if (envKey && envKey.length > 20 && envKey.startsWith("re_") && !envKey.includes("DEMO")) {
    return envKey
  }

  return providedKey
}

const RESEND_API_KEY = getValidApiKey()
const resend = new Resend(RESEND_API_KEY)

const getSchoolInfo = async (): Promise<{ name: string; phone: string; email: string }> => {
  try {
    // Import database here to avoid circular dependencies
    const { db } = await import("@/lib/database")
    const settings = await db.getSettings()
    return {
      name: settings.schoolName || "Smart Attendance Tracker",
      phone: settings.schoolPhone || "",
      email: settings.emailUsername || "yechale1216@gmail.com",
    }
  } catch (error) {
    console.error("Error getting school info:", error)
    return {
      name: "Smart Attendance Tracker",
      phone: "",
      email: "yechale1216@gmail.com",
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const { to, subject, text, html } = await request.json()

    if (!to || !subject || !text) {
      return NextResponse.json({ success: false, error: "Missing required fields: to, subject, text" }, { status: 400 })
    }

    const schoolInfo = await getSchoolInfo()
    const verifiedEmail = schoolInfo.email

    const isVerifiedRecipient = to === verifiedEmail

    if (!isVerifiedRecipient) {
      return NextResponse.json({
        success: true,
        demo: true,
        messageId: `demo_${Date.now()}`,
        message: "Email simulated - Trial account can only send to verified addresses",
        details: `To send real emails to ${to}, verify a domain at resend.com/domains and use an email from that domain as the 'from' address`,
      })
    }

    try {
      const data = await resend.emails.send({
        from: `${schoolInfo.name} <onboarding@resend.dev>`,
        to: [to],
        subject: subject,
        text: text,
        html: html || text.replace(/\n/g, "<br>"),
        replyTo: schoolInfo.email,
      })

      if (data.error) {
        console.error("Resend error:", data.error.message)
        return NextResponse.json(
          { success: false, error: data.error.message || "Failed to send email" },
          { status: 500 },
        )
      }

      return NextResponse.json({
        success: true,
        testing: false,
        messageId: data.data?.id,
        message: "Email sent successfully via Resend",
      })
    } catch (resendError: any) {
      console.error("Unexpected Resend API error:", resendError.message || resendError)

      return NextResponse.json({
        success: true,
        demo: true,
        messageId: `demo_${Date.now()}`,
        message: "Email simulated - Service temporarily unavailable",
        details: `Email sending failed: ${resendError.message || resendError}`,
      })
    }
  } catch (error) {
    console.error("Email API error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      },
      { status: 500 },
    )
  }
}
