import { type NextRequest, NextResponse } from "next/server"
import { authService } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const { token, password } = await request.json()

    if (!token || !password) {
      return NextResponse.json({ success: false, error: "Token and password are required" }, { status: 400 })
    }

    if (password.length < 6) {
      return NextResponse.json(
        { success: false, error: "Password must be at least 6 characters long" },
        { status: 400 },
      )
    }

    const result = await authService.resetPassword(token, password)

    if (result.success) {
      return NextResponse.json({
        success: true,
        message: "Password reset successfully",
      })
    } else {
      return NextResponse.json({ success: false, error: result.error || "Failed to reset password" }, { status: 400 })
    }
  } catch (error) {
    console.error("Reset password error:", error)
    return NextResponse.json({ success: false, error: "An error occurred processing your request" }, { status: 500 })
  }
}
