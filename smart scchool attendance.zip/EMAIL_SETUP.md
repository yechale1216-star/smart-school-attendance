# Email Configuration Setup

This attendance system now uses **Resend** for sending email notifications to parents. Here's how to set it up:

## Quick Setup

1. **Get a Resend API Key:**
   - Go to [resend.com](https://resend.com)
   - Sign up for a free account
   - Navigate to API Keys section
   - Create a new API key

2. **Add the API Key to Vercel:**
   - Go to your Vercel project dashboard
   - Navigate to Settings → Environment Variables
   - Add a new environment variable:
     - **Name:** `RESEND_API_KEY`
     - **Value:** Your Resend API key (starts with `re_`)

3. **Deploy:**
   - Redeploy your application for the changes to take effect

## How It Works

- **From Address:** Emails are sent from `onboarding@resend.dev` (Resend's default domain)
- **Reply-To Address:** Set to your Gmail address (`yechale1216@gmail.com`) so parents can reply directly to you
- **Fallback:** If no API key is configured, the system will simulate email sending for testing

## Email Templates

The system automatically sends notifications for:
- **Student Absences:** Notifies parents when a student is marked absent
- **Late Arrivals:** Alerts parents when a student arrives late
- **Excused Absences:** Confirms excused absences with parents

## Troubleshooting

- **Emails not sending?** Check that your `RESEND_API_KEY` environment variable is set correctly
- **Want to test?** The system works without an API key in demo mode
- **Need custom domain?** Upgrade your Resend plan to send from your own domain

## Free Tier Limits

Resend's free tier includes:
- 3,000 emails per month
- 100 emails per day
- Perfect for most schools' notification needs

---

**Your current configuration:**
- School: Addiss Hiwot School
- Reply-to Email: yechale1216@gmail.com
- Notifications: Enabled by default
